from pathlib import Path
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html

DATA = Path(__file__).resolve().parent / 'ecommerce_estatistica.csv'
df = pd.read_csv(DATA).drop(columns=['Unnamed: 0'], errors='ignore')
for col in ['Preço', 'Nota', 'N_Avaliações', 'Desconto']:
    df[col] = pd.to_numeric(df[col], errors='coerce')
for col in ['Marca', 'Material', 'Gênero', 'Temporada']:
    df[col] = df[col].fillna('Não informado').astype(str)

app = Dash(__name__)
server = app.server
app.title = 'Dashboard de E-commerce'

app.layout = html.Div([
    html.H1('Dashboard de Análise de E-commerce'),
    html.P('Análise interativa de preços, avaliações, descontos e características dos produtos.'),
    html.Div([
        html.Div([html.Label('Marca'), dcc.Dropdown(id='marca', options=[{'label': m, 'value': m} for m in sorted(df['Marca'].unique())], multi=True, placeholder='Todas as marcas')]),
        html.Div([html.Label('Gênero'), dcc.Dropdown(id='genero', options=[{'label': g, 'value': g} for g in sorted(df['Gênero'].unique())], multi=True, placeholder='Todos os gêneros')]),
        html.Div([html.Label('Faixa de preço (R$)'), dcc.RangeSlider(id='preco', min=float(df['Preço'].min()), max=float(df['Preço'].max()), value=[float(df['Preço'].min()), float(df['Preço'].max())], tooltip={'placement':'bottom', 'always_visible':False})]),
    ], className='filters'),
    html.Div(id='indicadores', className='metrics'),
    html.Div([
        dcc.Graph(id='hist-preco'), dcc.Graph(id='hist-nota'),
        dcc.Graph(id='marca-count'), dcc.Graph(id='material-count'),
        dcc.Graph(id='scatter'), dcc.Graph(id='box-genero'),
        dcc.Graph(id='desconto'), dcc.Graph(id='temporada')
    ], className='charts'),
    html.P('Fonte: ecommerce_estatistica.csv | Gráficos atualizados conforme os filtros.', className='footer')
], className='container')

@app.callback(
    Output('indicadores', 'children'),
    Output('hist-preco', 'figure'), Output('hist-nota', 'figure'),
    Output('marca-count', 'figure'), Output('material-count', 'figure'),
    Output('scatter', 'figure'), Output('box-genero', 'figure'),
    Output('desconto', 'figure'), Output('temporada', 'figure'),
    Input('marca', 'value'), Input('genero', 'value'), Input('preco', 'value')
)
def atualizar(marcas, generos, faixa):
    dados = df.copy()
    if marcas:
        dados = dados[dados['Marca'].isin(marcas)]
    if generos:
        dados = dados[dados['Gênero'].isin(generos)]
    dados = dados[dados['Preço'].between(faixa[0], faixa[1])]
    def card(rotulo, valor):
        return html.Div([html.Span(rotulo), html.Strong(valor)], className='metric')
    indicadores = [
        card('Produtos', f'{len(dados):,}'.replace(',', '.')),
        card('Preço médio', f'R$ {dados["Preço"].mean():.2f}' if len(dados) else '—'),
        card('Nota média', f'{dados["Nota"].mean():.2f}' if len(dados) else '—'),
        card('Desconto médio', f'{dados["Desconto"].mean():.1f}%' if len(dados) else '—'),
    ]
    figs = [
        px.histogram(dados, x='Preço', nbins=25, title='Distribuição de preços', labels={'Preço':'Preço (R$)'}),
        px.histogram(dados, x='Nota', nbins=20, title='Distribuição das notas'),
        px.bar(dados['Marca'].value_counts().head(10).rename_axis('Marca').reset_index(name='Produtos'), x='Marca', y='Produtos', title='10 marcas com mais produtos'),
        px.bar(dados['Material'].value_counts().head(10).rename_axis('Material').reset_index(name='Produtos'), x='Material', y='Produtos', title='10 materiais mais frequentes'),
        px.scatter(dados, x='Preço', y='Nota', hover_data=['Título'], title='Relação entre preço e avaliação'),
        px.box(dados, x='Gênero', y='Preço', title='Distribuição de preços por gênero'),
        px.histogram(dados, x='Desconto', nbins=20, title='Distribuição dos descontos'),
        px.pie(dados, names='Temporada', title='Participação por temporada')
    ]
    for fig in figs:
        fig.update_layout(template='plotly_white', margin=dict(l=35, r=20, t=60, b=45), paper_bgcolor='white')
        if dados.empty:
            fig.add_annotation(text='Nenhum produto corresponde aos filtros', x=0.5, y=0.5, xref='paper', yref='paper', showarrow=False)
    return (indicadores, *figs)

if __name__ == '__main__':
    app.run(debug=True)
