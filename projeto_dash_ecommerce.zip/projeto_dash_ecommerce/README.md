# Dashboard de E-commerce com Dash

Aplicação interativa construída com **Python, Pandas, Plotly e Dash** a partir do arquivo `ecommerce_estatistica.csv`.

## Recursos
- Filtros por marca, gênero e faixa de preço.
- Indicadores de quantidade de produtos, preço médio, nota média e desconto médio.
- Oito visualizações: histogramas de preços, notas e descontos; ranking de marcas e materiais; dispersão preço × nota; boxplot por gênero; gráfico de setores por temporada.

## Como executar localmente

1. Instale Python 3.10 ou superior.
2. No terminal, dentro da pasta do projeto, execute:

```bash
pip install -r requirements.txt
python app.py
```

3. Abra `http://127.0.0.1:8050` no navegador.

## Publicação

Envie os arquivos para um repositório GitHub. **O GitHub armazena o código, mas não hospeda a aplicação Dash em execução.** Para disponibilizar um link público da interface, use um serviço de hospedagem de aplicações Python (por exemplo, Render), com:

- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:server`

A aplicação deve ser executada com o arquivo CSV na mesma pasta de `app.py`.

## Entrega

Conforme o enunciado, envie o link do **repositório GitHub** no campo da atividade.
